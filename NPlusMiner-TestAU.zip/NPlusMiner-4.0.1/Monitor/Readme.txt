Replace the GTR 40 with GTR 70. This way, if a single card fails, it would still detect as a failure and reboot. 
A single card dying is 66.66% GPU usage, so would still be considered "Mining is working" if it was set to detect at 40.
This is an option for you to go in and edit one of these bat files that is equivalent with the number of cards you have on your system.
