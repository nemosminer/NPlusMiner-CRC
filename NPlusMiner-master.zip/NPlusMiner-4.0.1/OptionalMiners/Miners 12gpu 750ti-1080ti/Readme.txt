
This Miner combo uses mostly Tpruvot,KlausT latest along with DSTM & CLAYMORE for high combatibility and relibltly (not fastest hashing on some algos)
